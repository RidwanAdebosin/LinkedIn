import "./LeftAside.css";
import ProfileUrl from "../../../../assets/WhatsApp Image 2024-04-13 at 6.26.36 PM (1).jpeg";

const LeftAside = () => {
  return (
    <aside className="leftAside">
      <div className="profileContainer">
        <div className="topbarWrapper">
          <div className="topBar"></div>
          <img src={ProfileUrl} className="profileImg" />
          <div className="userDetails">
            <h1>Ridwan Adebosin</h1>
            <span>Software Developer</span>
          </div>
        </div>
        <hr />
        <div className="postAnalytics">
            <div className="postAnalytic">
                <p>Profile viewers</p>
                <span>51</span>
            </div>
            <div className="postAnalytic">
                <p>Post impressions</p>
                <span>25</span>
            </div>
        </div>
        <hr/>
        <div className="postAnalytics">
            <div className="postAnalytic">
               <p>Strengthen your profile with an Al writing assistant</p>
               <p>Try Premium for NGN0</p>
            </div>
            
            <div className="postAnalytic">
                <p>Post impressions</p>
                <span>25</span>
            </div>
        </div>
      </div>
      <div className="recentActivitiesContainer"></div>
    </aside>
  );
};

export default LeftAside;
