import "./RightAside.css";

const RightAside = () => {
    return(
        <aside className="rightAside">
           <div className="feedContainer"></div>
           <div className="footerContainer"></div>
       
    )
        </aside>
    )
}

export default RightAside;